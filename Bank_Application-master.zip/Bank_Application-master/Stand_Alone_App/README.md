Just runt the script bank_app.py and enjoy the bank app program
You only need to install python version 3 in your system
than open a command prompt and run the bank_app.py
