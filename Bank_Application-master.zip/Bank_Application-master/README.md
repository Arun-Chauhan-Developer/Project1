Requirements --> PYthon version 3.5 or upper
Packages --> pymysql  ( you can install by #pip install pymysql )
Other --> A SQL database  running on localhost at port 3306


BankApp_EXE_file --> contains a single bank_app.exe file just put it into a folder and double click it to run on windows system 

Bank_Package --> it is same file as BankApp the difference is it is divided into modules to make code easy understandable. it has different files having coding for debit, credit, profile, login and signup. The main file is bank_app.py which will run your project

Bank_App --> This  is base file having single file bank_app.py to run but it has dependency on SQL server running on localhost:80. To run this file first install a mysql server and run it on localhost:80 than open file database_create.py and change root password in it to the your password of database server. Than run database_create.py first which will create database and tables needed by project after that just run bank_app.py to run the project.

StandAloneApp --> It is independent package you can run directly, it uses sqlite3 database of python.
