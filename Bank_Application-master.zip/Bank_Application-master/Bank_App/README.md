Requirements --> python3 and a sql database server
Modules used --> tkinter module



This is just a simple Bank Appliction

first install database in your system such as mariadb or oracle MySQL
you can install xampp that is super easy and start your sql server

after this enter sql server root password into file "database_create.py"

than just run database_create.py first to setup your database known as bank and user as bank to work on this database as well as the password is also bank

than just run bank_app.py to use this basic tkinter project

