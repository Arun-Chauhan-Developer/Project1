Just Create a Folder named anything you want like bankapp or so

and put this bank_app.exe file over there 

and just doulble click it run your bank program

Enjoy it
